function toggle(id, className, visibleClassName) {
    const elements = document.getElementsByClassName(className);
    Array.from(elements).forEach(element => {
        if (element.id !== id) {
            element.classList.remove(visibleClassName);
        } else {
            element.classList.add(visibleClassName);
        }
    });
    resized();
}
function toggleMap(id) {
    toggle(id, "toggleMap", "toggleMapVisible")
}
function toggleLine(id) {
    toggle(id, "toggleLine", "toggleLineVisible")
}
function toggleBar(id) {
    toggle(id, "toggleBar", "toggleBarVisible")
}

function resizedDelay() {
    setTimeout(resized, 100);
}

function svgSetup() {
    window.onresize = resizedDelay;
    setTimeout(resized, 500);
}

function resized() {

    var svgs = d3.selectAll("svg").each(function() {

        const svg = d3.select(this);

        const displayWidth = svg.node().getBoundingClientRect().width
        if (displayWidth == 0) {
            return;
        }

        const width = svg.node().viewBox.baseVal.width
        
        const text = svg.selectAll("text");

        const grid = svg.selectAll("line");

        const scale = width / displayWidth;

        console.log(scale);

        // Fix grid size at 1px too
        grid.style("stroke-width", scale + "px");

        // Increase text scale proportional to overall scale reduction
        // e.g. 3/4 of the original width -> scale text by 4/3
        text.attr("transform", "scale(" + scale + " " + scale + ")");
    })

}